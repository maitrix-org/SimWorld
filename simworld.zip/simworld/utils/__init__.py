"""Utility modules and helpers for the SimWorld package.

This package contains various utility functions for mathematical operations,
vector manipulation, data export, and other common operations needed
throughout the simulation.
"""
