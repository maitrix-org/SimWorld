"""City generation and management modules.

This package provides components for procedural city generation,
including roads, buildings, and other urban elements.
"""
