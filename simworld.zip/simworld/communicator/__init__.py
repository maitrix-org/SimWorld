"""Communication modules for interfacing with Unreal Engine.

This package provides the necessary classes and functions for communicating
with Unreal Engine through the UnrealCV interface.
"""
