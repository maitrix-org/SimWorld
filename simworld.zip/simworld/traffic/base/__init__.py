"""Base module for traffic simulation components.

This module contains the core classes and structures for representing and managing
traffic elements in the simulation environment.
"""
