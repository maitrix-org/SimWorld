"""Prompt module: defines system and user prompt templates for SimWorld agents."""
